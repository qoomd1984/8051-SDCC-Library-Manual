#ifndef __STC8H_H_
#define __STC8H_H_

/////////////////////////////////////////////////
//----------------

__sfr __at	(0x80)	P0	;
__sfr __at	(0x81)	SP	;
__sfr __at	(0x82)	DPL	;
__sfr __at	(0x83)	DPH	;
//__sfr __at	(0x84)	S4CON ;
__sfr __at	(0x85)	S4BUF ;
__sfr __at	(0x87)	PCON ; //can not be sbit
#define SMOD        0x80
#define SMOD0       0x40
#define LVDF        0x20
#define POF         0x10
#define GF1         0x08
#define GF0         0x04
#define PD          0x02
#define IDL         0x01

__sfr __at	(0x88) TCON ; //can be sbit
__sbit __at (0x88) IT0  ;
__sbit __at (0x89) IE0  ;
__sbit __at (0x8A) IT1  ;
__sbit __at (0x8B) IE1  ;
__sbit __at (0x8C) TR0  ;
__sbit __at (0x8D) TF0  ;
__sbit __at (0x8E) TR1  ;
__sbit __at (0x8F) TF1  ;

__sfr __at	(0x89)  TMOD ;
#define T0_M0       0x01
#define T0_M1       0x02
#define T0_CT       0x04
#define T0_GATE     0x08
#define T1_M0       0x10
#define T1_M1       0x20
#define T1_CT       0x40
#define T1_GATE     0x80

__sfr __at	(0x8a) TL0	;
__sfr __at	(0x8b) TL1	;
__sfr __at	(0x8c) TH0	;
__sfr __at	(0x8d) TH1	;
__sfr __at	(0xd1) T4T3M;
#define T3CLKO      0x01
#define T3x12       0x02
#define T3_CT       0x04
#define T3R         0x08
#define T4CLKO      0x10
#define T4x12       0x20
#define T4_CT       0x40
#define T4R         0x80

__sfr __at	(0x8E) AUXR;
#define S1ST2		0x01
#define EXTRAM		0x02
#define T2x12		0x04
#define T2_CT		0x08
#define T2R		0x10
#define UART_M0x6	0x20
#define T1x12		0x40
#define T0x12		0x80

__sfr __at	(0x8F) INT_CLK0;
#define T0CLK0		0x01
#define T1CLK0		0x02
#define T2CLK0		0x04
#define	INT_CLK0_3	0x08
#define EX2			0x10
#define EX3			0x20
#define EX4			0x40
#define	INT_CLK0_7	0x80

__sfr __at	(0x80)	P0 ;
__sbit __at (0x80)	P00	;
__sbit __at (0x81)	P01	;
__sbit __at (0x82)	P02	;
__sbit __at (0x83)	P03	;
__sbit __at (0x84)	P04 ;
__sbit __at (0x85)	P05 ;
__sbit __at (0x86)	P06	;
__sbit __at (0x87)	P07 ;

__sfr __at	(0x90)	P1 ;
__sbit __at (0x90)	P10	;
__sbit __at (0x91)	P11	;
__sbit __at (0x92)	P12	;
__sbit __at (0x93)	P13	;
__sbit __at (0x94)	P14 ;
__sbit __at (0x95)	P15 ;
__sbit __at (0x96)	P16	;
__sbit __at (0x97)	P17 ;

__sfr __at	(0x94)  P0M0 ;
__sfr __at	(0x93)	P0M1 ;
__sfr __at	(0x92)	P1M0 ;
__sfr __at	(0x91)	P1M1 ;
__sfr __at	(0x96) 	P2M0 ;
__sfr __at	(0x95) 	P2M1 ;

__sfr __at	(0x97) 	PCON2 ;
#define CLKS0		0x01
#define CLKS1		0x02
#define CLKS2		0x04
#define	MCLKO_2		0x08
#define Tx_Rx		0x10
#define ADRJ		0x20
#define MCKO_S0		0x40
#define	MCKO_S1		0x80

__sfr __at	(0x98) 	SCON ;
__sbit __at (0x98)	RI  ;
__sbit __at (0x99)	TI  ;
__sbit __at (0x9A)	RB8  ;
__sbit __at (0x9B)	TB8  ;
__sbit __at (0x9C)	REN  ;
__sbit __at (0x9D)	SM2  ;
__sbit __at (0x9E)	SM1  ;
__sbit __at (0x9F)	SM0_FE  ;

__sfr __at	(0x99)	SBUF ;

__sfr __at	(0x9A) 	S2CON ;
#define S2RI		0x01
#define S2TI		0x02
#define S2RB8		0x04
#define	S2TB8		0x08
#define S2REN		0x10
#define S2SM2		0x20
#define S2CON_6		0x40
#define	S2SM0		0x80

__sfr __at	(0x84) 	S4CON ;
#define S4RI		0x01
#define S4TI		0x02
#define S4RB8		0x04
#define	S4TB8		0x08
#define S4REN		0x10
#define S4SM2		0x20
#define S4ST4		0x40
#define	S4SM0		0x80

__sfr __at	(0x9B)	S2BUF ;

__sfr __at	(0xa0)	P2 ;
__sbit __at (0xa0)	P20 ;
__sbit __at (0xa1)	P21 ;
__sbit __at (0xa2)	P22 ;
__sbit __at (0xa3)	P23 ;
__sbit __at (0xa4)	P24 ;
__sbit __at (0xa5)	P25 ;
__sbit __at (0xa6)	P26 ;
__sbit __at (0xa7)	P27 ;

__sfr __at	(0xA1)	BUS_SPEED ;

__sfr __at	(0xA2)	P_SW1 ;
#define DPS			0x01
#define P_SW1_1		0x02
#define SPI_S0		0x04
#define	SPI_S1		0x08
#define CCP_S0		0x10
#define CCP_S1		0x20
#define S1_S0		0x40
#define	S1_S1		0x80

__sfr __at	(0xa8)	IE	;
__sbit __at (0xa8)	EX0	;
__sbit __at (0xa9)	ET0 ;
__sbit __at (0xaa)	EX1 ;
__sbit __at (0xab)	ET1 ;
__sbit __at (0xac)	ES  ;
__sbit __at (0xad)	EADC ;
__sbit __at (0xae)	ELVD ;
__sbit __at (0xaf)	EA	;

__sfr __at	(0xa9)	SADDR ;
__sfr __at	(0xaa)	WKTCL ;
__sfr __at	(0xab)	WKTCH ;

__sfr __at	(0xac)	S3CON ;
#define S3RI		0x01
#define S3TI		0x02
#define S3RB8		0x04
#define	S3TB8		0x08
#define S3REN		0x10
#define S3SM2		0x20
#define S3ST3		0x40
#define	S3SM0		0x80

__sfr __at	(0xad)	S3BUF ;

__sfr __at	(0xaf)	IE2	;
#define ES2         0x01
#define ESPI        0x02
#define ET2         0x04
#define ES3         0x08
#define ES4         0x10
#define ET3         0x20
#define ET4         0x40
#define IE2_7		0x80

__sfr __at	(0xb0)	P3	;
__sbit __at (0xb0)	P30 ;
__sbit __at (0xb1)	P31 ;
__sbit __at (0xb2)	P32 ;
__sbit __at (0xb3)	P33 ;
__sbit __at (0xb4)	P34 ;
__sbit __at (0xb5)	P35 ;
__sbit __at (0xb6)	P36 ;
__sbit __at (0xb7)	P37 ;

__sfr __at	(0xb2) 	P3M0	;
__sfr __at	(0xb1) 	P3M1	;
__sfr __at	(0xb4) 	P4M0	;
__sfr __at	(0xb3) 	P4M1	;

__sfr __at	(0xb5)  IP2	;
#define PS2		0x01
#define PSPI        	0x02
#define PPWM		0x04
#define PPWMFD		0x08
#define PX4         	0x10
#define IP2_5		0x20
#define IP2_6		0x40
#define IP2_7		0x80

__sfr __at	(0xb6)	IP2H	;
#define PS2H		0x01
#define PSPIH		0x02
#define PPWMH		0x04
#define PPWMFDH		0x08
#define PX4H		0x10
#define PCMPH		0x20
#define PI2CH		0x40
#define IP2H_7		0x80

__sfr __at	(0xb7)  IPH	;
#define	PX0H 0x01
#define PT0H 0x02
#define PX1H 0x04
#define PT1H 0x08
#define PSH  0x10
#define PADCH 0x20
#define PLVDH 0x40
#define PPCAH 0x80

__sfr __at	(0xb8)  IP	;
__sbit __at (0xb8)	PX0 ;
__sbit __at (0xb9)	PT0 ;
__sbit __at (0xba)	PX1 ;
__sbit __at (0xbb)	PT1 ;
__sbit __at (0xbc)	PS  ;
__sbit __at (0xbd)	PADC ;
__sbit __at (0xbe)	PLVD ;
__sbit __at (0xbf)	IP_7 ;

__sfr __at	(0xb9)	SADEN ;

__sfr __at	(0xba)	P_SW2 ;
#define S2_S0		0x01
#define S3_S0		0x02
#define S4_S0		0x04
#define CMPO_S		0x08
#define I2C_S0		0x10
#define I2C_S1		0x20
#define P_SW2_6		0x40
#define EAXFR		0x80

__sfr __at	(0xbc)	ADC_CONTR ;
#define ADC_CHS0	0x01
#define ADC_CHS1	0x02
#define ADC_CHS2	0x04
#define ADC_CHS3	0x08
#define ADC_EPWMT	0x10
#define ADC_FLAG	0x20
#define ADC_START	0x40
#define ADC_POWER	0x80

__sfr __at	(0xbd)	ADC_RES ;
__sfr __at	(0xbe)	ADC_RESL ;

__sfr __at	(0xc0)	P4	;
__sbit __at (0xc0)	P40 ;
__sbit __at (0xc1)	P41 ;
__sbit __at (0xc2)	P42 ;
__sbit __at (0xc3)	P43 ;
__sbit __at (0xc4)	P44 ;
__sbit __at (0xc5)	P45 ;
__sbit __at (0xc6)	P46 ;
__sbit __at (0xc7)	P47 ;


__sfr __at	(0xc1)	WDT_CONTR ;
#define WDT_PS0		0x01
#define WDT_PS1		0x02
#define WDT_PS2		0x04
#define IDEL_WDT	0x08
#define CLR_WDT		0x10
#define EN_WDT		0x20
#define WDT_CONTR_6	0x40
#define WDT_FLAG	0x80

__sfr __at	(0xc2)	IAP_DATA ;
__sfr __at	(0xc3)	IAP_ADDRH ;
__sfr __at	(0xc4)	IAP_ADDRL ;
__sfr __at	(0xc5)	IAP_CMD ;
__sfr __at	(0xc6)	IAP_TRIG ;
__sfr __at	(0xc7)	IAP_CONTR ;

__sfr __at	(0xc8)	P5	;
__sbit __at (0xc8)	P50 ;
__sbit __at (0xc9)	P51 ;
__sbit __at (0xca)	P52 ;
__sbit __at (0xcb)	P53 ;
__sbit __at (0xcc)	P54 ;
__sbit __at (0xcd)	P55 ;
__sbit __at (0xce)	P56 ;
__sbit __at (0xcf)	P57 ;

__sfr __at	(0xca) 	P5M0 ;
__sfr __at	(0xc9) 	P5M1 ;
__sfr __at	(0xcc)	P6M0 ;
__sfr __at	(0xcb) 	P6M1 ;

__sfr __at	(0xcd) 	SPSTAT ;
#define SPSTAT_0	0x01
#define SPSTAT_1	0x02
#define SPSTAT_2	0x04
#define SPSTAT_3	0x08
#define SPSTAT_4	0x10
#define SPSTAT_5	0x20
#define WCOL		0x40
#define SPIF		0x80

__sfr __at	(0xce) 	SPCTL ;
#define SPR0		0x01
#define SPR1		0x02
#define CPHA		0x04
#define CPOL		0x08
#define MSTR		0x10
#define DORD		0x20
#define SPEN		0x40
#define SSIG		0x80

__sfr __at (0xcf)	SPDAT ;

__sfr __at (0xd0)	PSW	;
__sbit __at (0xd0)	P	;
__sbit __at (0xd1)	F1	;
__sbit __at (0xd2)	OV	;
__sbit __at (0xd3)	RS0	;
__sbit __at (0xd4)	RS1 ;
__sbit __at (0xd5)	F0 ;
__sbit __at (0xd6)	AC	;
__sbit __at (0xd7)	CY ;

__sfr __at	(0xD2) T4H ;
__sfr __at	(0xD3) T4L ;
__sfr __at	(0xD4) T3H ;
__sfr __at	(0xD5) T3L ;
__sfr __at	(0xD6) T2H ;
__sfr __at	(0xD7) T2L ;
__sfr __at	(0x8d) T1H	;
__sfr __at	(0x8b) T1L	;
__sfr __at	(0x8c) T0H	;
__sfr __at	(0x8a) T0L	;
__sfr __at	(0xd2) TH4	;
__sfr __at	(0xd3) TL4	;
__sfr __at	(0xd4) TH3	;
__sfr __at	(0xd5) TL3	;
__sfr __at	(0xd6) TH2	;
__sfr __at	(0xd7) TL2	;
__sfr __at	(0x8d) TH1	;
__sfr __at	(0x8b) TL1	;
__sfr __at	(0x8c) TH0	;
__sfr __at	(0x8a) TL0	;

__sfr __at	(0xd8)	CCON ;
__sbit __at (0xd8)	CCF0 ;
__sbit __at (0xd9)	CCF1 ;
__sbit __at (0xda)	CCF2 ;
__sbit __at (0xdb)	CCF3 ;
__sbit __at (0xdc)	CCON_4 ;
__sbit __at (0xdd)	CCON_5 ;
__sbit __at (0xde)	CR ;
__sbit __at (0xdf)	CF ;

__sfr __at	(0xd9) 	CMOD ;
#define ECF			0x01
#define CPS0		0x02
#define CPS1		0x04
#define CMOD_3		0x08
#define CMOD_4		0x10
#define CMOD_5		0x20
#define CMOD_6		0x40
#define CIDL		0x80

__sfr __at	(0xda) 	CCAPM0 ;
#define ECCF0		0x01
#define PWM0		0x02
#define TOG0		0x04
#define MAT0		0x08
#define CAPN0		0x10
#define CAPP0		0x20
#define ECOM0		0x40
#define CCAPM0_7	0x80

__sfr __at	(0xdb) 	CCAPM1 ;
#define ECCF1		0x01
#define PWM1		0x02
#define TOG1		0x04
#define MAT1		0x08
#define CAPN1		0x10
#define CAPP1		0x20
#define ECOM1		0x40
#define CCAPM1_7	0x80

__sfr __at	(0xdc) 	CCAPM2 ;
#define ECCF2		0x01
#define PWM2		0x02
#define TOG2		0x04
#define MAT2		0x08
#define CAPN2		0x10
#define CAPP2		0x20
#define ECOM2		0x40
#define CCAPM2_7	0x80

__sfr __at	(0xde) 	ADCCFG ;
#define ADC_SPEED0	0x01
#define ADC_SPEED1	0x02
#define ADC_SPEED2	0x04
#define ADC_SPEED3	0x08
#define ADCCFG_4	0x10
#define RESFMT		0x20
#define ADCCFG_6	0x40
#define ADCCFG_7	0x80

__sfr __at (0xe0)	ACC	;
__sfr __at (0xe2) 	P7M0 ;
__sfr __at (0xe1) 	P7M1 ;

__sfr __at	(0xe8)	P6	;
__sbit __at (0xe8)	P60 ;
__sbit __at (0xe9)	P61 ;
__sbit __at (0xea)	P62 ;
__sbit __at (0xeb)	P63 ;
__sbit __at (0xec)	P64 ;
__sbit __at (0xed)	P65 ;
__sbit __at (0xee)	P66 ;
__sbit __at (0xef)	P67 ;

__sfr __at	(0xf8)	P7	;
__sbit __at (0xf8)	P70 ;
__sbit __at (0xf9)	P71 ;
__sbit __at (0xfa)	P72 ;
__sbit __at (0xfb)	P73 ;
__sbit __at (0xfc)	P74 ;
__sbit __at (0xfe)	P75 ;
__sbit __at (0xfd)	P76 ;
__sbit __at (0xff)	P77 ;



__sfr __at (0xe9) 	CL ;
__sfr __at (0xea) 	CCAP0L ;
__sfr __at (0xea) 	CCAP1L ;
__sfr __at (0xea) 	CCAP2L ;

__sfr __at (0xf0)	B ;

__sfr __at	(0xf1) 	PWMCFG ;
#define C2INI		0x01
#define C3INI		0x02
#define C4INI		0x04
#define C5INI		0x08
#define C6INI		0x10
#define C7INI		0x20
#define C8INI		0x40
#define CBTADC		0x80

__sfr __at	(0xf2) 	PCA_PWM0 ;
#define EPC0L		0x01
#define EPC0H		0x02
#define PCA_PWM0_2	0x04
#define PCA_PWM0_3	0x08
#define PCA_PWM0_4	0x10
#define PCA_PWM0_5	0x20
#define EBS0_0		0x40
#define EBS0_1		0x80

__sfr __at	(0xf3) 	PCA_PWM1 ;
#define EPC1L		0x01
#define EPC1H		0x02
#define PCA_PWM1_2	0x04
#define PCA_PWM1_3	0x08
#define PCA_PWM1_4	0x10
#define PCA_PWM1_5	0x20
#define EBS1_0		0x40
#define EBS1_1		0x80

__sfr __at	(0xf4) 	PCA_PWM2 ;
#define EPC2L		0x01
#define EPC2H		0x02
#define PCA_PWM2_2	0x04
#define PCA_PWM2_3	0x08
#define PCA_PWM2_4	0x10
#define PCA_PWM2_5	0x20
#define EBS2_0		0x40
#define EBS2_1		0x80

__sfr __at	(0xf5) 	PWMCR ;
#define ENC2O		0x01
#define ENC3O		0x02
#define ENC4O		0x04
#define ENC5O		0x08
#define ENC6O		0x10
#define ENC7O		0x20
#define ECBI		0x40
#define ENPWM		0x80

__sfr __at	(0xf6) 	PWMIF ;
#define C2IF		0x01
#define C3IF		0x02
#define C4IF		0x04
#define C5IF		0x08
#define C6IF		0x10
#define C7IF		0x20
#define CBIF		0x40
#define PWMIF_7		0x80

__sfr __at	(0xf6) 	PWMFDCR ;
#define FDIF		0x01
#define FDIO		0x02
#define FDCMP		0x04
#define EFDI		0x08
#define FLTFLIO		0x10
#define ENFD		0x20
#define PWMFDCR_6	0x40
#define PWMFDCR_7	0x80

__sfr __at	(0xff) RSTCFG	;
#define ENLVR	0x40                    //RSTCFG.6
#define LVD2V0	0x00                    //LVD@2.0V
#define LVD2V4	0x01                    //LVD@2.4V
#define LVD2V7	0x02                    //LVD@2.7V
#define LVD3V0	0x03                    //LVD@3.0V


//�������⹦�ܼĴ���λ����չRAM����
//������Щ�Ĵ���,���Ƚ�P_SW2��BIT7����Ϊ1,�ſ�������д
#define PWMC        (*(unsigned int  volatile __xdata *)0xfff0)
#define PWMCH       (*(unsigned char volatile __xdata *)0xfff0)
#define PWMCL       (*(unsigned char volatile __xdata *)0xfff1)
#define PWMCKS      (*(unsigned char volatile __xdata *)0xfff2)
#define TADCP       (*(unsigned char volatile __xdata *)0xfff3)
#define TADCPH      (*(unsigned char volatile __xdata *)0xfff3)
#define TADCPL      (*(unsigned char volatile __xdata *)0xfff4)
#define PWM0T1      (*(unsigned int  volatile __xdata *)0xff00)
#define PWM0T1H     (*(unsigned char volatile __xdata *)0xff00)
#define PWM0T1L     (*(unsigned char volatile __xdata *)0xff01)
#define PWM0T2      (*(unsigned int  volatile __xdata *)0xff02)
#define PWM0T2H     (*(unsigned char volatile __xdata *)0xff02)
#define PWM0T2L     (*(unsigned char volatile __xdata *)0xff03)
#define PWM0CR      (*(unsigned char volatile __xdata *)0xff04)
#define PWM0HLD     (*(unsigned char volatile __xdata *)0xff05)
#define PWM1T1      (*(unsigned int  volatile __xdata *)0xff10)
#define PWM1T1H     (*(unsigned char volatile __xdata *)0xff10)
#define PWM1T1L     (*(unsigned char volatile __xdata *)0xff11)
#define PWM1T2      (*(unsigned int  volatile __xdata *)0xff12)
#define PWM1T2H     (*(unsigned char volatile __xdata *)0xff12)
#define PWM1T2L     (*(unsigned char volatile __xdata *)0xff13)
#define PWM1CR      (*(unsigned char volatile __xdata *)0xff14)
#define PWM1HLD     (*(unsigned char volatile __xdata *)0xff15)
#define PWM2T1      (*(unsigned int  volatile __xdata *)0xff20)
#define PWM2T1H     (*(unsigned char volatile __xdata *)0xff20)
#define PWM2T1L     (*(unsigned char volatile __xdata *)0xff21)
#define PWM2T2      (*(unsigned int  volatile __xdata *)0xff22)
#define PWM2T2H     (*(unsigned char volatile __xdata *)0xff22)
#define PWM2T2L     (*(unsigned char volatile __xdata *)0xff23)
#define PWM2CR      (*(unsigned char volatile __xdata *)0xff24)
#define PWM2HLD     (*(unsigned char volatile __xdata *)0xff25)
#define PWM3T1      (*(unsigned int  volatile __xdata *)0xff30)
#define PWM3T1H     (*(unsigned char volatile __xdata *)0xff30)
#define PWM3T1L     (*(unsigned char volatile __xdata *)0xff31)
#define PWM3T2      (*(unsigned int  volatile __xdata *)0xff32)
#define PWM3T2H     (*(unsigned char volatile __xdata *)0xff32)
#define PWM3T2L     (*(unsigned char volatile __xdata *)0xff33)
#define PWM3CR      (*(unsigned char volatile __xdata *)0xff34)
#define PWM3HLD     (*(unsigned char volatile __xdata *)0xff35)
#define PWM4T1      (*(unsigned int  volatile __xdata *)0xff40)
#define PWM4T1H     (*(unsigned char volatile __xdata *)0xff40)
#define PWM4T1L     (*(unsigned char volatile __xdata *)0xff41)
#define PWM4T2      (*(unsigned int  volatile __xdata *)0xff42)
#define PWM4T2H     (*(unsigned char volatile __xdata *)0xff42)
#define PWM4T2L     (*(unsigned char volatile __xdata *)0xff43)
#define PWM4CR      (*(unsigned char volatile __xdata *)0xff44)
#define PWM4HLD     (*(unsigned char volatile __xdata *)0xff45)
#define PWM5T1      (*(unsigned int  volatile __xdata *)0xff50)
#define PWM5T1H     (*(unsigned char volatile __xdata *)0xff50)
#define PWM5T1L     (*(unsigned char volatile __xdata *)0xff51)
#define PWM5T2      (*(unsigned int  volatile __xdata *)0xff52)
#define PWM5T2H     (*(unsigned char volatile __xdata *)0xff52)
#define PWM5T2L     (*(unsigned char volatile __xdata *)0xff53)
#define PWM5CR      (*(unsigned char volatile __xdata *)0xff54)
#define PWM5HLD     (*(unsigned char volatile __xdata *)0xff55)
#define PWM6T1      (*(unsigned int  volatile __xdata *)0xff60)
#define PWM6T1H     (*(unsigned char volatile __xdata *)0xff60)
#define PWM6T1L     (*(unsigned char volatile __xdata *)0xff61)
#define PWM6T2      (*(unsigned int  volatile __xdata *)0xff62)
#define PWM6T2H     (*(unsigned char volatile __xdata *)0xff62)
#define PWM6T2L     (*(unsigned char volatile __xdata *)0xff63)
#define PWM6CR      (*(unsigned char volatile __xdata *)0xff64)
#define PWM6HLD     (*(unsigned char volatile __xdata *)0xff65)
#define PWM7T1      (*(unsigned int  volatile __xdata *)0xff70)
#define PWM7T1H     (*(unsigned char volatile __xdata *)0xff70)
#define PWM7T1L     (*(unsigned char volatile __xdata *)0xff71)
#define PWM7T2      (*(unsigned int  volatile __xdata *)0xff72)
#define PWM7T2H     (*(unsigned char volatile __xdata *)0xff72)
#define PWM7T2L     (*(unsigned char volatile __xdata *)0xff73)
#define PWM7CR      (*(unsigned char volatile __xdata *)0xff74)
#define PWM7HLD     (*(unsigned char volatile __xdata *)0xff75)

//I2C���⹦�ܼĴ���
//�������⹦�ܼĴ���λ����չRAM����
//������Щ�Ĵ���,���Ƚ�P_SW2��BIT7����Ϊ1,�ſ�������д
#define I2CCFG      (*(unsigned char volatile __xdata *)0xfe80)
#define ENI2C       0x80
#define MSSL        0x40
#define I2CMSCR     (*(unsigned char volatile __xdata *)0xfe81)
#define EMSI        0x80
#define I2CMSST     (*(unsigned char volatile __xdata *)0xfe82)
#define MSBUSY      0x80
#define MSIF        0x40
#define MSACKI      0x02
#define MSACKO      0x01
#define I2CSLCR     (*(unsigned char volatile __xdata *)0xfe83)
#define ESTAI       0x40
#define ERXI        0x20
#define ETXI        0x10
#define ESTOI       0x08
#define SLRST       0x01
#define I2CSLST     (*(unsigned char volatile __xdata *)0xfe84)
#define SLBUSY      0x80
#define STAIF       0x40
#define RXIF        0x20
#define TXIF        0x10
#define STOIF       0x08
#define TXING       0x04
#define SLACKI      0x02
#define SLACKO      0x01
#define I2CSLADR    (*(unsigned char volatile __xdata *)0xfe85)
#define I2CTXD      (*(unsigned char volatile __xdata *)0xfe86)
#define I2CRXD      (*(unsigned char volatile __xdata *)0xfe87)
#define ADCTIM      (*(unsigned char volatile __xdata *)0xFEA8)

//volatile __xdata unsigned char __at (0xFEA8) ADCTIM;
#define CSSETUP		0x80
#define CSHOLD1     0x40
#define CSHOLD0     0x20
#define SMPDUTY4	0x10
#define SMPDUTY3    0x08
#define SMPDUTY2    0x04
#define SMPDUTY1    0x02
#define SMPDUTY0    0x01



/*
 * Interrupt Vectors, number = (addr - 3)/8 = 
 */
#define extern0_VECTOR	0 //0x03 /* External interrupt 0 */
#define IE0_VECTOR		0 //0x03 /* External interrupt 0 */
#define TF0_VECTOR		1 //0x0B /* Timer 0 Interrupt */
#define timer0_VECTOR	1 //0x0B /* Timer 0 Interrupt */
#define IE1_VECTOR		2 //0x13 /* External interrupt 1 */
#define extern1_VECTOR	2 //0x13 /* External interrupt 1 */
#define TF1_VECTOR		3 //0x1B /* Timer 1 Interrupt */
#define timer1_VECTOR	3 //0x1B /* Timer 1 Interrupt */
#define TI_VECTOR		4 //0x23 /* Serial Port1 Interrupt */
#define SerialTI_VECTOR	4 //0x23 /* Serial Port1 Interrupt */
#define RI_VECTOR		4 //0x23 /* Serial Port1 Interrupt */
#define SerialRE_VECTOR 4 //0x23 /* Serial Port1 Interrupt */
#define uart1_TR_VECTOR 4 //0x23 /* Serial Port1 Interrupt */
#define ADC_VECTOR 		5 //0x2B /* ADC Interrupt */
#define LVD_VECTOR 		6 //0x33 /* LVD Interrupt */
#define CCP_PCA_PWM_VECTOR	7 //0x3B /* CCP/PCA/PWM Interrupt */
#define uart2_TR_VECTOR		8 //0x43 /* Serial Port2 Interrupt */
#define SPI_VECTOR			9 //0x4B /* SPI Interrupt */
#define extern2_VECTOR		10 //0x53 /* External interrupt 2 */
#define IE2_VECTOR			10 //0x53 /* External Interrupt 2 */
#define extern3_VECTOR		11 //0x5B /* External interrupt 3 */
#define IE3_VECTOR			11 //0x5B /* External Interrupt 3 */
#define TF2_VECTOR			12 //0x63 /* Timer 2 Interrupt */
#define timer2_VECTOR		12 //0x63 /* Timer 2 Interrupt */
#define extern4_VECTOR		16 //0x83 /* External interrupt 4 */
#define IE4_VECTOR			16 //0x83 /* External Interrupt 4 */
#define uart3_TR_VECTOR		17 //0x8B /* Serial Port3 Interrupt */
#define uart4_TR_VECTOR		18 //0x93 /* Serial Port4 Interrupt */
#define TF3_VECTOR			19 //0x9B /* Timer 3 Interrupt */
#define timer3_VECTOR		19 //0x9B /* Timer 3 Interrupt */
#define TF4_VECTOR			20 //0xA3 /* Timer 4 Interrupt */
#define timer4_VECTOR		20 //0xA3 /* Timer 4 Interrupt */
#define COMP_VECTOR			21 //0xAB /* Comparator Interrupt */
#define PWM_VECTOR			22 //0xB3 /* PWM Interrupt */
#define PWM_ERR_VECTOR		23 //0xBB /* PWM ERR Interrupt */

/////////////////////////////////////////////////

#endif /* __STC8H_H_ */


