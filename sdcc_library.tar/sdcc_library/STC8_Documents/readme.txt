STC8 8051 MCU library

compiler: sdcc v3.8.0




Uart V1.2,V1.3

uart_2.lib
uart_3.lib
timer_2.lib

22.1184MHz CPU ClOCK;
